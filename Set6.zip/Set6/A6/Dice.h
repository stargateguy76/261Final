//
// Created by Allan Huntington on 2019-10-28.
//

#ifndef SET1_DICE_H
#define SET1_DICE_H
int rollDie();
void printHand(int x[]);
int rollDice(int x[]);
#endif //SET1_DICE_H
